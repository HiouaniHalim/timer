package sample;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import com.sun.istack.internal.NotNull;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    private double x = 0, y = 0;
    private JFXTextField[] jfxTextFields;
    private Label[] labels;
    private clock c;

    @FXML
    private JFXButton start, reset;

    @FXML
    private Label h, m, s, say;

    @FXML
    private JFXTextField hour, minute, second;

    /**
     * Called to initialize a controller after its root element has been
     * completely processed.
     *
     * @param location  The location used to resolve relative paths for the root object, or
     *                  <tt>null</tt> if the location is not known.
     * @param resources The resources used to localize the root object, or <tt>null</tt> if
     */

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        jfxTextFields = new JFXTextField[] {hour, minute, second};
        labels = new Label[] {h, m, s, say};
    }

    @FXML
    private void onMousePressed(MouseEvent event){
        x = event.getSceneX();
        y = event.getSceneY();
    }

    @FXML
    private void onMouseDragged(MouseEvent event){
        Clock.stage.setX(event.getScreenX() - x);
        Clock.stage.setY(event.getScreenY() - y);
    }


    @FXML
    private void handleKeyEventHours(KeyEvent event){
        keyType(event, h, hour);
    }

    @FXML
    private void handleKeyEventMinutes(KeyEvent event){
        keyType(event, m, minute);
    }

    @FXML
    private void handleKeyEventSeconds(KeyEvent event){
        keyType(event, s, second);
    }

    private void keyType(KeyEvent event, Label label, JFXTextField textField){
        int input = textField.getText().length();
        char c = event.getCharacter().charAt(0);

        if (!(Character.isDigit(c))) event.consume();
        else if (textField.getText().length() > 1) event.consume();

        if (textField.getText().isEmpty()) Platform.runLater(()-> label.setText("00"));
        else if (input == 0) Platform.runLater(()-> label.setText("00"));
        else Platform.runLater(()-> label.setText(textField.getText()));

    }

    /* fin typed */

    @FXML
    private void handleKeyEvent(KeyEvent event){
        switch (event.getCode()){
            case ESCAPE:
                System.exit(0);
                break;

            case DELETE:
                for (Label label : labels) {
                    label.setText("00");
                }
                for (JFXTextField jfxTextField : jfxTextFields) {
                    jfxTextField.setText("");
                }
                break;

            case ENTER:
                second.setDisable(false);
                second.setText("");
                break;
        }
    }

    @FXML
    private void handleMousePressed(MouseEvent event) {

        int timer = Integer.parseInt(labels[0].getText()) * 3600 + Integer.parseInt(labels[1].getText()) * 60 + Integer.parseInt(labels[2].getText());
        int[] values = new int[]{Integer.parseInt(h.getText()), Integer.parseInt(m.getText()), Integer.parseInt(s.getText())};

        if (Objects.equals(event.getTarget(), start)){
            for (JFXTextField field : jfxTextFields) field.setDisable(true);
            Platform.runLater(() -> say.setText(String.valueOf(timer)));
            c = clock.value(values[0], values[1], values[2], labels);
            c.start();

        }

        else if (Objects.equals(event.getTarget(), reset)){
            for (JFXTextField field : jfxTextFields) field.setDisable(false);
            c.stop();
            System.out.println("null");
        }
    }

    @FXML
    private void close(){
        System.exit(0);
    }

    @FXML
    private void resize(){
        Clock.stage.setIconified(true);
    }

    static class clock{
        static Thread thread = null;

        private @NotNull int hours;
        private @NotNull int minutes;
        private @NotNull int seconds;
        private  Label[] labels;

        private clock(@NotNull int hours, @NotNull int minutes, @NotNull int seconds, Label[] labels){
            this.hours = hours;
            this.minutes = minutes;
            this.seconds = seconds;
            this.labels = labels;
        }

        static clock value(@NotNull int hours, @NotNull int minutes, @NotNull int seconds, Label[] labels){
            return new clock(hours, minutes, seconds, labels);
        }

        private void start(){
            thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    int timer = hours * 3600 + minutes * 60 + seconds;

                    for (int i = timer; i >= 0; i--) {
                        System.out.println(i);
                        try {
                            Thread.sleep(1000);
                            int finalI = i;
                            Platform.runLater(() -> labels[3].setText(String.valueOf(finalI)));
                            if (i == 0){
                                System.out.println("shutdown start...");
                                Runtime.getRuntime().exec("shutdown -s");
                            }
                        } catch (InterruptedException | IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
            thread.start();
        }

        private void stop(){
            Platform.runLater(() -> labels[3].setText("00"));
            thread.stop();
        }
    }
}
